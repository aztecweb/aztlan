<?php
/**
 * Theme start file
 *
 * @package Aztec
 */

get_header();?>
<h1>Child Theme</h1>
<?php get_footer();
