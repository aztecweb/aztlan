<?php
/**
 * Plugin Name: Private Aztlan Plugin
 * Description: Private plugin example.
 * Version: 0.1
 * Author: Aztec Online Solutions
 * Author URI: http://aztecweb.net/
 */
