<?php
/**
 * Plugin Name: Private Env Plugin
 * Description: Private plugin example.
 * Version: 1.0
 * Author: Aztec Online Solutions
 * Author URI: http://aztecweb.net/
 */
